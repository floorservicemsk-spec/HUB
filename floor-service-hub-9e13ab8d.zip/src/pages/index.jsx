import React from "react";
import HomeSplash from "./HomeSplash";

export default function IndexPage() {
  return <HomeSplash />;
}
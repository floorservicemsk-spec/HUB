import { base44 } from './base44Client';


export const syncXmlFeed = base44.functions.syncXmlFeed;

export const generateQuotePDF = base44.functions.generateQuotePDF;

export const sendQuoteEmail = base44.functions.sendQuoteEmail;

export const proxyFetch = base44.functions.proxyFetch;

export const computeDealerTiers = base44.functions.computeDealerTiers;

